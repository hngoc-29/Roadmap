// ============================================================
// COMPONENTS/CONTENT-DETAIL-ACTIONS.TSX
// ============================================================
// Client component: Edit + Delete buttons trên trang content detail

"use client";

import { useRouter } from "next/navigation";
import { useTransition, useState } from "react";
import { deleteContent } from "@/actions/content";

interface ContentDetailActionsProps {
  contentId: string;
  contentSlug: string;
}

export default function ContentDetailActions({ contentId, contentSlug }: ContentDetailActionsProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [confirming, setConfirming] = useState(false);

  const handleDelete = () => {
    if (!confirming) { setConfirming(true); return; }
    startTransition(async () => {
      try {
        await deleteContent(contentId);
        router.push("/content");
        router.refresh();
      } catch (err) {
        console.error(err);
        alert("Lỗi khi xóa nội dung");
        setConfirming(false);
      }
    });
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <button
        onClick={() => router.push(`/content/${contentSlug}/edit`)}
        className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
      >
        ✏️ Chỉnh sửa
      </button>

      {confirming ? (
        <div className="flex items-center gap-2">
          <span className="text-sm text-red-600 dark:text-red-400 font-medium">Xóa nội dung này?</span>
          <button
            onClick={handleDelete}
            disabled={isPending}
            className="text-sm font-medium px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 transition-colors"
          >
            {isPending ? "Đang xóa..." : "✅ Xác nhận xóa"}
          </button>
          <button
            onClick={() => setConfirming(false)}
            className="text-sm font-medium px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
          >
            Hủy
          </button>
        </div>
      ) : (
        <button
          onClick={handleDelete}
          className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400 transition-colors"
        >
          🗑️ Xóa
        </button>
      )}
    </div>
  );
}

// ============================================================
// COMPONENTS/BLOG-CARD-ACTIONS.TSX
// ============================================================
// Client component: Edit + Delete buttons cho blog card

"use client";

import { useRouter } from "next/navigation";
import { useTransition, useState } from "react";
import { deletePost } from "@/actions/post";

interface BlogCardActionsProps {
  postId: string;
  postSlug: string;
}

export default function BlogCardActions({ postId, postSlug }: BlogCardActionsProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [confirming, setConfirming] = useState(false);

  const handleDelete = () => {
    if (!confirming) { setConfirming(true); return; }
    startTransition(async () => {
      try {
        await deletePost(postId);
        router.refresh();
      } catch (err) {
        console.error(err);
        alert("Lỗi khi xóa bài viết");
      } finally {
        setConfirming(false);
      }
    });
  };

  return (
    <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-border">
      <button
        onClick={(e) => { e.preventDefault(); router.push(`/blog/${postSlug}/edit`); }}
        className="flex-1 text-xs font-medium px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
      >
        ✏️ Chỉnh sửa
      </button>

      <button
        onClick={(e) => { e.preventDefault(); handleDelete(); }}
        disabled={isPending}
        className={`flex-1 text-xs font-medium px-3 py-1.5 rounded-lg transition-colors disabled:opacity-50 ${
          confirming
            ? "bg-red-600 text-white hover:bg-red-700"
            : "bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400"
        }`}
      >
        {isPending ? "Đang xóa..." : confirming ? "⚠️ Xác nhận?" : "🗑️ Xóa"}
      </button>

      {confirming && (
        <button
          onClick={(e) => { e.preventDefault(); setConfirming(false); }}
          className="text-xs px-2 py-1.5 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
        >
          Hủy
        </button>
      )}
    </div>
  );
}

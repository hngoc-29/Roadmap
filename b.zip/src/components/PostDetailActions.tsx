// ============================================================
// COMPONENTS/POST-DETAIL-ACTIONS.TSX
// ============================================================
// Client component: Edit + Delete buttons trên trang blog detail

"use client";

import { useRouter } from "next/navigation";
import { useTransition, useState } from "react";
import { deletePost } from "@/actions/post";

interface PostDetailActionsProps {
  postId: string;
  postSlug: string;
  isPublished: boolean;
}

export default function PostDetailActions({ postId, postSlug, isPublished }: PostDetailActionsProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [confirming, setConfirming] = useState(false);

  const handleDelete = () => {
    if (!confirming) { setConfirming(true); return; }
    startTransition(async () => {
      try {
        await deletePost(postId);
        router.push("/blog");
        router.refresh();
      } catch (err) {
        console.error(err);
        alert("Lỗi khi xóa bài viết");
        setConfirming(false);
      }
    });
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <button
        onClick={() => router.push(`/blog/${postSlug}/edit`)}
        className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
      >
        ✏️ Chỉnh sửa
      </button>

      {confirming ? (
        <div className="flex items-center gap-2">
          <span className="text-sm text-red-600 dark:text-red-400 font-medium">Xóa bài viết này?</span>
          <button
            onClick={handleDelete}
            disabled={isPending}
            className="text-sm font-medium px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 transition-colors"
          >
            {isPending ? "Đang xóa..." : "✅ Xác nhận xóa"}
          </button>
          <button
            onClick={() => setConfirming(false)}
            className="text-sm font-medium px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
          >
            Hủy
          </button>
        </div>
      ) : (
        <button
          onClick={handleDelete}
          className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400 transition-colors"
        >
          🗑️ Xóa bài viết
        </button>
      )}

      <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
        isPublished
          ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
          : "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400"
      }`}>
        {isPublished ? "🌐 Public" : "📝 Draft"}
      </span>
    </div>
  );
}

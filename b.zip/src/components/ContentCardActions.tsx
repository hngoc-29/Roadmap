// ============================================================
// COMPONENTS/CONTENT-CARD-ACTIONS.TSX
// ============================================================
// Client component: Edit + Delete buttons cho content card

"use client";

import { useRouter } from "next/navigation";
import { useTransition, useState } from "react";
import { deleteContent } from "@/actions/content";

interface ContentCardActionsProps {
  contentId: string;
  contentSlug: string;
}

export default function ContentCardActions({ contentId, contentSlug }: ContentCardActionsProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [confirming, setConfirming] = useState(false);

  const handleDelete = () => {
    if (!confirming) { setConfirming(true); return; }
    startTransition(async () => {
      try {
        await deleteContent(contentId);
        router.refresh();
      } catch (err) {
        console.error(err);
        alert("Lỗi khi xóa nội dung");
      } finally {
        setConfirming(false);
      }
    });
  };

  return (
    <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-border">
      <button
        onClick={(e) => { e.preventDefault(); router.push(`/content/${contentSlug}/edit`); }}
        className="flex-1 text-xs font-medium px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
      >
        ✏️ Sửa
      </button>

      <button
        onClick={(e) => { e.preventDefault(); handleDelete(); }}
        disabled={isPending}
        className={`flex-1 text-xs font-medium px-3 py-1.5 rounded-lg transition-colors disabled:opacity-50 ${
          confirming
            ? "bg-red-600 text-white hover:bg-red-700"
            : "bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400"
        }`}
      >
        {isPending ? "Đang xóa..." : confirming ? "⚠️ Xác nhận?" : "🗑️ Xóa"}
      </button>

      {confirming && (
        <button
          onClick={(e) => { e.preventDefault(); setConfirming(false); }}
          className="text-xs px-2 py-1.5 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
        >
          Hủy
        </button>
      )}
    </div>
  );
}

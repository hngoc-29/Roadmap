// ============================================================
// COMPONENTS/NOTE-DETAIL-ACTIONS.TSX
// ============================================================
// Client component: Pin / Edit / Delete trên trang note detail

"use client";

import { useRouter } from "next/navigation";
import { useTransition, useState } from "react";
import { deleteNote, togglePinNote } from "@/actions/note";

interface NoteDetailActionsProps {
  noteId: string;
  noteSlug: string;
  isPinned: boolean;
}

export default function NoteDetailActions({ noteId, noteSlug, isPinned }: NoteDetailActionsProps) {
  const router = useRouter();
  const [deletePending, startDeleteTransition] = useTransition();
  const [pinPending,    startPinTransition]    = useTransition();
  const [confirming, setConfirming] = useState(false);
  const [pinned, setPinned] = useState(isPinned);

  const handlePin = () => {
    startPinTransition(async () => {
      try {
        await togglePinNote(noteId, !pinned);
        setPinned(!pinned);
        router.refresh();
      } catch (err) {
        console.error(err);
      }
    });
  };

  const handleDelete = () => {
    if (!confirming) { setConfirming(true); return; }
    startDeleteTransition(async () => {
      try {
        await deleteNote(noteId);
        router.push("/notes");
        router.refresh();
      } catch (err) {
        console.error(err);
        alert("Lỗi khi xóa ghi chú");
        setConfirming(false);
      }
    });
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {/* Pin */}
      <button
        onClick={handlePin}
        disabled={pinPending}
        className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 disabled:opacity-50 transition-colors"
      >
        {pinPending ? "..." : pinned ? "📌 Bỏ ghim" : "📍 Ghim"}
      </button>

      {/* Edit */}
      <button
        onClick={() => router.push(`/notes/${noteSlug}/edit`)}
        className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
      >
        ✏️ Chỉnh sửa
      </button>

      {/* Delete */}
      {confirming ? (
        <div className="flex items-center gap-2">
          <span className="text-sm text-red-600 dark:text-red-400 font-medium">Xóa ghi chú này?</span>
          <button
            onClick={handleDelete}
            disabled={deletePending}
            className="text-sm font-medium px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 transition-colors"
          >
            {deletePending ? "Đang xóa..." : "✅ Xác nhận"}
          </button>
          <button
            onClick={() => setConfirming(false)}
            className="text-sm font-medium px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
          >
            Hủy
          </button>
        </div>
      ) : (
        <button
          onClick={handleDelete}
          className="inline-flex items-center gap-1.5 text-sm font-medium px-4 py-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-400 transition-colors"
        >
          🗑️ Xóa ghi chú
        </button>
      )}
    </div>
  );
}

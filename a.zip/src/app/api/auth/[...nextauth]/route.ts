// ============================================================
// API/AUTH/[...NEXTAUTH]/ROUTE.TS - NextAuth Route Handler
// ============================================================

import NextAuth from "next-auth";
import { authOptions } from "@/lib/auth";

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };

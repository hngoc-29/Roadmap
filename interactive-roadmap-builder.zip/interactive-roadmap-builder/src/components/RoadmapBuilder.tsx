// ============================================================
// COMPONENTS/ROADMAP-BUILDER.TSX - Core Interactive Component
// ============================================================
// ✅ Client Component: React Flow cần browser APIs
// ✅ Pattern: Server fetches data → truyền vào đây qua props
// ✅ Xử lý cả hai chế độ: View (navigate) & Edit (modal)

"use client";

import { useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  addEdge,
  useNodesState,
  useEdgesState,
  type NodeMouseHandler,
  type OnConnect,
  BackgroundVariant,
  Panel,
} from "reactflow";
import "reactflow/dist/style.css";
import { nanoid } from "nanoid";

import type { IRoadmap, RoadmapNodeData, AppMode } from "@/types";
import { saveRoadmapGraph } from "@/actions/roadmap";
import { createSlug } from "@/lib/utils";
import NodeEditModal from "./NodeEditModal";
import CustomRoadmapNode from "./CustomRoadmapNode";

// ──────────────────────────────────────────────
// Custom Node Types - phải định nghĩa ngoài component
// để tránh React Flow re-render không cần thiết
// ──────────────────────────────────────────────
const nodeTypes = {
  roadmapNode: CustomRoadmapNode,
};

// ──────────────────────────────────────────────
// PROPS
// ──────────────────────────────────────────────
interface RoadmapBuilderProps {
  roadmap: IRoadmap;
  mode?: AppMode;
}

// ──────────────────────────────────────────────
// MAIN COMPONENT
// ──────────────────────────────────────────────
export default function RoadmapBuilder({
  roadmap,
  mode: initialMode = "view",
}: RoadmapBuilderProps) {
  const router = useRouter();

  // ── App Mode State ──
  const [mode, setMode] = useState<AppMode>(initialMode);

  // ── React Flow State ──
  // useNodesState/useEdgesState tự động handle add/remove/update
  const [nodes, setNodes, onNodesChange] = useNodesState(
    roadmap.nodes.map((n) => ({
      id: n.id,
      type: n.type ?? "roadmapNode",
      position: n.position,
      data: n.data as RoadmapNodeData,
    }))
  );

  const [edges, setEdges, onEdgesChange] = useEdgesState(
    roadmap.edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      type: e.type ?? "smoothstep",
      animated: e.animated,
      label: e.label,
    }))
  );

  // ── Modal State ──
  const [editingNode, setEditingNode] = useState<{
    id: string;
    data: RoadmapNodeData;
  } | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // ── Save State ──
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState("");
  const saveTimeoutRef = useRef<ReturnType<typeof setTimeout>>(null);

  // ──────────────────────────────────────────────
  // ✅ KEY HANDLER: onNodeClick
  // Logic phân nhánh theo mode
  // ──────────────────────────────────────────────
  const onNodeClick: NodeMouseHandler = useCallback(
    (event, node) => {
      event.preventDefault();

      if (mode === "view") {
        // ── CHẾ ĐỘ XEM: Navigate đến trang bài học ──
        // next/navigation's router.push = client-side navigation
        // (không reload trang, UX mượt mà)
        const nodeData = node.data as RoadmapNodeData;

        if (nodeData.status === "locked") {
          // Không cho phép truy cập bài bị khóa
          return;
        }

        router.push(`/roadmap/${roadmap.slug}/${nodeData.slug}`);
      } else {
        // ── CHẾ ĐỘ CHỈNH SỬA: Mở modal edit ──
        setEditingNode({
          id: node.id,
          data: node.data as RoadmapNodeData,
        });
        setIsModalOpen(true);
      }
    },
    [mode, roadmap.slug, router]
  );

  // ──────────────────────────────────────────────
  // onConnect: Vẽ edge mới khi kéo từ handle này sang handle khác
  // ──────────────────────────────────────────────
  const onConnect: OnConnect = useCallback(
    (connection) => {
      if (mode !== "edit") return;
      setEdges((eds) =>
        addEdge(
          {
            ...connection,
            id: nanoid(),
            type: "smoothstep",
            animated: false,
          },
          eds
        )
      );
    },
    [mode, setEdges]
  );

  // ──────────────────────────────────────────────
  // Thêm Node mới vào giữa canvas
  // ──────────────────────────────────────────────
  const handleAddNode = useCallback(() => {
    const newLabel = "Node mới";
    const newNode = {
      id: nanoid(),
      type: "roadmapNode" as const,
      position: { x: 300 + Math.random() * 200, y: 200 + Math.random() * 200 },
      data: {
        label: newLabel,
        slug: createSlug(newLabel) + "-" + nanoid(4),
        content: "# " + newLabel + "\n\nThêm nội dung ở đây...",
        status: "available" as const,
        icon: "📚",
      } satisfies RoadmapNodeData,
    };
    setNodes((nds) => [...nds, newNode]);
  }, [setNodes]);

  // ──────────────────────────────────────────────
  // Lưu thay đổi vào MongoDB
  // ──────────────────────────────────────────────
  const handleSave = useCallback(async () => {
    if (isSaving) return;
    setIsSaving(true);
    setSaveMessage("");

    try {
      await saveRoadmapGraph(roadmap._id!, {
        nodes: nodes.map((n) => ({
          id: n.id,
          type: n.type,
          position: n.position,
          data: n.data as RoadmapNodeData,
        })),
        edges: edges.map((e) => ({
          id: e.id,
          source: e.source,
          target: e.target,
          type: e.type,
          animated: e.animated,
          label: e.label as string | undefined,
        })),
      });
      setSaveMessage("✅ Đã lưu thành công!");
    } catch (error) {
      setSaveMessage("❌ Lỗi khi lưu. Thử lại sau.");
      console.error(error);
    } finally {
      setIsSaving(false);
      // Tự động ẩn message sau 3s
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = setTimeout(() => setSaveMessage(""), 3000);
    }
  }, [isSaving, nodes, edges, roadmap._id]);

  // ──────────────────────────────────────────────
  // Cập nhật node sau khi save modal
  // ──────────────────────────────────────────────
  const handleNodeSave = useCallback(
    (nodeId: string, newData: RoadmapNodeData) => {
      setNodes((nds) =>
        nds.map((n) => (n.id === nodeId ? { ...n, data: newData } : n))
      );
      setIsModalOpen(false);
      setEditingNode(null);
    },
    [setNodes]
  );

  // ──────────────────────────────────────────────
  // RENDER
  // ──────────────────────────────────────────────
  return (
    <div id="roadmap-canvas" className="w-full relative">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={mode === "edit" ? onNodesChange : undefined}
        onEdgesChange={mode === "edit" ? onEdgesChange : undefined}
        onConnect={mode === "edit" ? onConnect : undefined}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        // ✅ PERFORMANCE: Tắt các tính năng không cần trong view mode
        nodesDraggable={mode === "edit"}
        nodesConnectable={mode === "edit"}
        elementsSelectable={mode === "edit"}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        minZoom={0.3}
        maxZoom={2}
        // ✅ Accessibility
        aria-label={`Roadmap: ${roadmap.title}`}
        attributionPosition="bottom-right"
      >
        {/* Nền lưới */}
        <Background variant={BackgroundVariant.Dots} gap={20} size={1} />

        {/* Controls zoom */}
        <Controls showInteractive={mode === "edit"} />

        {/* Minimap: thu nhỏ toàn bộ graph */}
        <MiniMap
          nodeColor={(node) => {
            const status = (node.data as RoadmapNodeData).status;
            if (status === "completed") return "#22c55e";
            if (status === "active") return "#3b82f6";
            if (status === "locked") return "#9ca3af";
            return "#e2e8f0";
          }}
          pannable
          zoomable
        />

        {/* ── Toolbar Panel (top-left) ── */}
        <Panel position="top-left">
          <div className="flex items-center gap-2 bg-card border border-border rounded-xl px-3 py-2 shadow-sm">
            {/* Mode Toggle */}
            <button
              onClick={() => setMode(mode === "view" ? "edit" : "view")}
              className={`text-xs font-medium px-3 py-1.5 rounded-lg transition-colors ${
                mode === "edit"
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              }`}
              aria-label={`Chuyển sang chế độ ${mode === "view" ? "chỉnh sửa" : "xem"}`}
            >
              {mode === "view" ? "✏️ Chỉnh sửa" : "👁️ Xem"}
            </button>

            {/* Add Node - chỉ hiện khi edit */}
            {mode === "edit" && (
              <>
                <button
                  onClick={handleAddNode}
                  className="text-xs font-medium px-3 py-1.5 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors"
                >
                  ➕ Thêm node
                </button>
                <button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="text-xs font-medium px-3 py-1.5 rounded-lg bg-green-600 text-white hover:bg-green-700 disabled:opacity-50 transition-colors"
                >
                  {isSaving ? "Đang lưu..." : "💾 Lưu"}
                </button>
              </>
            )}
          </div>

          {/* Save status message */}
          {saveMessage && (
            <div className="mt-2 text-xs bg-card border border-border px-3 py-2 rounded-lg shadow-sm animate-fade-in">
              {saveMessage}
            </div>
          )}
        </Panel>

        {/* Roadmap title */}
        <Panel position="top-center">
          <h1 className="text-sm font-semibold bg-card border border-border px-4 py-2 rounded-xl shadow-sm">
            {roadmap.title}
          </h1>
        </Panel>
      </ReactFlow>

      {/* ✅ Edit Modal */}
      {isModalOpen && editingNode && (
        <NodeEditModal
          nodeId={editingNode.id}
          nodeData={editingNode.data}
          roadmapId={roadmap._id!}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setEditingNode(null);
          }}
          onSave={handleNodeSave}
        />
      )}
    </div>
  );
}

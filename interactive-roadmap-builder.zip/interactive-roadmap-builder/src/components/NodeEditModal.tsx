// ============================================================
// COMPONENTS/NODE-EDIT-MODAL.TSX - Modal chỉnh sửa bài học
// ============================================================
// ✅ Client Component: dùng Radix UI Dialog
// ✅ Tabs: Preview Markdown real-time bên cạnh editor
// ✅ Auto-generate slug từ label

"use client";

import { useState, useCallback, useTransition } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { updateNodeContent } from "@/actions/roadmap";
import { createSlug } from "@/lib/utils";
import type { RoadmapNodeData } from "@/types";

interface NodeEditModalProps {
  nodeId: string;
  nodeData: RoadmapNodeData;
  roadmapId: string;
  isOpen: boolean;
  onClose: () => void;
  onSave: (nodeId: string, newData: RoadmapNodeData) => void;
}

type TabType = "edit" | "preview";

export default function NodeEditModal({
  nodeId,
  nodeData,
  roadmapId,
  isOpen,
  onClose,
  onSave,
}: NodeEditModalProps) {
  // Local state - copy từ nodeData để edit
  const [label, setLabel] = useState(nodeData.label);
  const [slug, setSlug] = useState(nodeData.slug);
  const [content, setContent] = useState(nodeData.content ?? "");
  const [description, setDescription] = useState(nodeData.description ?? "");
  const [icon, setIcon] = useState(nodeData.icon ?? "📚");
  const [estimatedTime, setEstimatedTime] = useState(nodeData.estimatedTime ?? "");
  const [difficulty, setDifficulty] = useState(nodeData.difficulty ?? "beginner");
  const [activeTab, setActiveTab] = useState<TabType>("edit");
  const [slugEdited, setSlugEdited] = useState(false); // track nếu user tự sửa slug

  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState("");

  // Auto-generate slug khi label thay đổi (chỉ khi user chưa tự sửa slug)
  const handleLabelChange = useCallback(
    (val: string) => {
      setLabel(val);
      if (!slugEdited) {
        setSlug(createSlug(val) || slug);
      }
    },
    [slugEdited, slug]
  );

  // Lưu lên DB và update local state
  const handleSave = useCallback(() => {
    if (!label.trim()) {
      setError("Label không được để trống");
      return;
    }
    if (!slug.trim()) {
      setError("Slug không được để trống");
      return;
    }
    setError("");

    const newData: RoadmapNodeData = {
      ...nodeData,
      label: label.trim(),
      slug: slug.trim(),
      content,
      description: description.trim(),
      icon,
      estimatedTime: estimatedTime.trim(),
      difficulty: difficulty as RoadmapNodeData["difficulty"],
    };

    startTransition(async () => {
      try {
        await updateNodeContent(roadmapId, nodeId, {
          label: newData.label,
          content: newData.content,
          description: newData.description,
          slug: newData.slug,
        });
        onSave(nodeId, newData);
      } catch (err) {
        setError("Lỗi khi lưu. Vui lòng thử lại.");
        console.error(err);
      }
    });
  }, [label, slug, content, description, icon, estimatedTime, difficulty, nodeData, roadmapId, nodeId, onSave]);

  return (
    <Dialog.Root open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <Dialog.Portal>
        {/* Overlay */}
        <Dialog.Overlay className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" />

        {/* Modal Content */}
        <Dialog.Content
          className="fixed left-1/2 top-1/2 z-50 -translate-x-1/2 -translate-y-1/2
                     w-[95vw] max-w-3xl max-h-[90vh] overflow-hidden
                     bg-card border border-border rounded-2xl shadow-2xl
                     flex flex-col
                     data-[state=open]:animate-in data-[state=closed]:animate-out
                     data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0
                     data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95"
          aria-describedby="modal-description"
        >
          {/* ── Header ── */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-border flex-shrink-0">
            <Dialog.Title className="text-lg font-semibold">
              ✏️ Chỉnh sửa bài học
            </Dialog.Title>
            <Dialog.Close
              className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              aria-label="Đóng"
            >
              ✕
            </Dialog.Close>
          </div>

          {/* ── Body (scrollable) ── */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            <p id="modal-description" className="sr-only">
              Form chỉnh sửa nội dung bài học trong roadmap
            </p>

            {/* Error */}
            {error && (
              <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-lg px-4 py-2">
                {error}
              </div>
            )}

            {/* Row 1: Icon + Label */}
            <div className="flex gap-3">
              <div className="w-24">
                <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                  Icon
                </label>
                <input
                  type="text"
                  value={icon}
                  onChange={(e) => setIcon(e.target.value)}
                  className="w-full border border-input bg-background rounded-lg px-3 py-2 text-center text-xl focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="📚"
                  maxLength={2}
                />
              </div>
              <div className="flex-1">
                <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                  Tiêu đề bài học <span className="text-destructive">*</span>
                </label>
                <input
                  type="text"
                  value={label}
                  onChange={(e) => handleLabelChange(e.target.value)}
                  className="w-full border border-input bg-background rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="VD: Giới thiệu về HTML"
                />
              </div>
            </div>

            {/* Row 2: Slug */}
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                Slug (URL){" "}
                <span className="text-muted-foreground font-normal">
                  – tự động tạo từ tiêu đề
                </span>
              </label>
              <div className="flex items-center gap-2 border border-input bg-background rounded-lg px-3 py-2 focus-within:ring-2 focus-within:ring-ring">
                <span className="text-xs text-muted-foreground whitespace-nowrap">
                  /roadmap/.../
                </span>
                <input
                  type="text"
                  value={slug}
                  onChange={(e) => {
                    setSlug(e.target.value.toLowerCase().replace(/\s+/g, "-"));
                    setSlugEdited(true);
                  }}
                  className="flex-1 text-sm bg-transparent focus:outline-none font-mono"
                  placeholder="ten-bai-hoc"
                />
              </div>
            </div>

            {/* Row 3: Description */}
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                Mô tả ngắn{" "}
                <span className="text-muted-foreground font-normal">
                  (dùng cho SEO meta description)
                </span>
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                maxLength={300}
                className="w-full border border-input bg-background rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="Mô tả ngắn gọn về nội dung bài học..."
              />
              <p className="text-xs text-muted-foreground text-right mt-1">
                {description.length}/300
              </p>
            </div>

            {/* Row 4: EstimatedTime + Difficulty */}
            <div className="flex gap-3">
              <div className="flex-1">
                <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                  Thời gian ước tính
                </label>
                <input
                  type="text"
                  value={estimatedTime}
                  onChange={(e) => setEstimatedTime(e.target.value)}
                  className="w-full border border-input bg-background rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="VD: 2 giờ, 30 phút"
                />
              </div>
              <div className="flex-1">
                <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                  Mức độ
                </label>
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value)}
                  className="w-full border border-input bg-background rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="beginner">🟢 Cơ bản</option>
                  <option value="intermediate">🟡 Trung cấp</option>
                  <option value="advanced">🔴 Nâng cao</option>
                </select>
              </div>
            </div>

            {/* Row 5: Markdown Editor với Tab Preview */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-muted-foreground">
                  Nội dung bài học{" "}
                  <span className="font-normal">(Markdown)</span>
                </label>
                {/* Tab buttons */}
                <div className="flex gap-1 bg-muted rounded-lg p-1">
                  <button
                    type="button"
                    onClick={() => setActiveTab("edit")}
                    className={`text-xs px-3 py-1 rounded-md transition-colors ${
                      activeTab === "edit"
                        ? "bg-background shadow-sm text-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    📝 Soạn thảo
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab("preview")}
                    className={`text-xs px-3 py-1 rounded-md transition-colors ${
                      activeTab === "preview"
                        ? "bg-background shadow-sm text-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    👁️ Preview
                  </button>
                </div>
              </div>

              {activeTab === "edit" ? (
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={12}
                  className="w-full border border-input bg-background rounded-lg px-3 py-2 text-sm font-mono resize-y focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder={`# Tiêu đề bài học\n\nNhập nội dung Markdown ở đây...\n\n## Nội dung chính\n\n- Điểm 1\n- Điểm 2\n\n\`\`\`javascript\n// Code example\nconsole.log("Hello World!");\n\`\`\``}
                  spellCheck={false}
                />
              ) : (
                // Preview: render Markdown đơn giản phía client
                // (Server MDX render chỉ dùng cho production page)
                <div
                  className="min-h-[200px] border border-border rounded-lg p-4 prose prose-sm prose-slate dark:prose-invert max-w-none overflow-y-auto"
                  style={{ maxHeight: "300px" }}
                >
                  {content ? (
                    <pre className="whitespace-pre-wrap text-sm font-sans">
                      {content}
                    </pre>
                  ) : (
                    <p className="text-muted-foreground italic text-sm">
                      Chưa có nội dung để preview...
                    </p>
                  )}
                </div>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                Hỗ trợ Markdown đầy đủ: tiêu đề, danh sách, code blocks, bảng...
              </p>
            </div>
          </div>

          {/* ── Footer ── */}
          <div className="flex items-center justify-between px-6 py-4 border-t border-border flex-shrink-0 bg-muted/30">
            <p className="text-xs text-muted-foreground">
              Thay đổi slug sẽ ảnh hưởng đến URL SEO của bài học này.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                disabled={isPending}
                className="px-4 py-2 text-sm rounded-lg border border-border hover:bg-muted transition-colors disabled:opacity-50"
              >
                Hủy
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={isPending}
                className="px-4 py-2 text-sm font-medium rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors"
              >
                {isPending ? "Đang lưu..." : "💾 Lưu bài học"}
              </button>
            </div>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

// ============================================================
// TYPES & INTERFACES - Toàn bộ type definitions cho dự án
// ============================================================

import type { Node as RFNode, Edge as RFEdge } from "reactflow";

// ──────────────────────────────────────────────
// 1. ROADMAP NODE DATA (dữ liệu custom trong mỗi node)
// ──────────────────────────────────────────────
export interface RoadmapNodeData {
  label: string;
  slug: string;
  content: string; // Markdown string
  description?: string; // Mô tả ngắn cho SEO meta description
  status?: "locked" | "available" | "active" | "completed";
  icon?: string; // emoji hoặc lucide icon name
  estimatedTime?: string; // e.g., "2 giờ", "3 ngày"
  difficulty?: "beginner" | "intermediate" | "advanced";
  tags?: string[];
  prerequisites?: string[]; // mảng node slugs
  resources?: Array<{
    title: string;
    url: string;
    type: "article" | "video" | "course" | "book";
  }>;
}

// ──────────────────────────────────────────────
// 2. REACT FLOW NODE & EDGE TYPES
// ──────────────────────────────────────────────
export type RoadmapNode = RFNode<RoadmapNodeData>;
export type RoadmapEdge = RFEdge;

// ──────────────────────────────────────────────
// 3. ROADMAP DOCUMENT (MongoDB document shape)
// ──────────────────────────────────────────────
export interface IRoadmap {
  _id?: string;
  title: string;
  slug: string;
  description: string; // SEO description
  author: {
    name: string;
    avatar?: string;
  };
  category?: string; // e.g., "Frontend", "Backend", "DevOps"
  tags?: string[];
  coverImage?: string;
  nodes: Array<{
    id: string;
    type?: string; // React Flow node type
    position: { x: number; y: number };
    data: RoadmapNodeData;
  }>;
  edges: Array<{
    id: string;
    source: string;
    target: string;
    type?: string;
    animated?: boolean;
    label?: string;
    style?: Record<string, string | number>;
  }>;
  isPublished: boolean;
  viewCount?: number;
  createdAt?: Date;
  updatedAt?: Date;
}

// ──────────────────────────────────────────────
// 4. APP MODE
// ──────────────────────────────────────────────
export type AppMode = "view" | "edit";

// ──────────────────────────────────────────────
// 5. API RESPONSE TYPES
// ──────────────────────────────────────────────
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// ──────────────────────────────────────────────
// 6. SEO METADATA HELPERS
// ──────────────────────────────────────────────
export interface PageSeoProps {
  title: string;
  description: string;
  url: string;
  image?: string;
  publishedTime?: string;
  modifiedTime?: string;
  tags?: string[];
  type?: "website" | "article";
}

// ──────────────────────────────────────────────
// 7. ROADMAP BUILDER PROPS
// ──────────────────────────────────────────────
export interface RoadmapBuilderProps {
  roadmap: IRoadmap;
  mode: AppMode;
  onSave?: (updatedRoadmap: IRoadmap) => Promise<void>;
}
